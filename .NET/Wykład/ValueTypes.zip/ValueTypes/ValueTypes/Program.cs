﻿using System;

namespace ValueTypes
{
    class PointClass
    {
        public int x;
        public int y;
        public PointClass(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public override string ToString()
        {
            return $"{nameof(PointClass)}({x},{y})";
        }
    }

    struct PointStruct
    {
        public int x;
        public int y;
        public PointStruct(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public override string ToString()
        {
            return $"{nameof(PointStruct)}({x},{y})";
        }
    }

    enum State: short {
        NotKnown,           // 0
        New,                // 1
        PreRun=10,          // 10
        Running,            // 11
        Executing=Running,  // 11
        Finishing,          // 12
        Fnished,            // 13
        Dead=20+2*5+New     // 31
    }

    [Flags] enum Direction
    {
        None,
        Up = 1,
        Down = 2,
        Left = 4,
        Right = 8
    }

    class Program
    {
        static void DeclarationOfPoints()
        {
            PointClass pc1=new PointClass(1,1);
            PointStruct ps1 = new PointStruct(2, 2);
            PointClass pc2 = pc1;
            PointStruct ps2 = ps1;
            pc2.x = 3;
            ps2.x = 4;
            System.Console.WriteLine($"{pc1}, {pc2}");
            System.Console.WriteLine($"{ps1}, {ps2}");
        }

        static void TestWithArgs(PointClass pcArg, PointStruct psArg)
        {
            pcArg.x = 11;
            psArg.x = 12;
            pcArg = new PointClass(100, 100);
            psArg = new PointStruct(200, 200);
        }

        static void TestWithRef(ref PointClass pcArg, ref PointStruct psArg)
        {
            pcArg.x = 11;
            psArg.x = 12;
            pcArg = new PointClass(100, 100);
            psArg = new PointStruct(200, 200);
        }
        static void TestWithOut(out PointClass pcArg, out PointStruct psArg)
        {
            //pcArg.x = 11; // compile error - pc parameter may not be initialized
            //psArg.x++; // compile error, the x field of the ps structure may be uninitialized
            psArg.x = 12; //st2, this is a value type, the ps field must "exist" and the entire ps structure also
            pcArg = new PointClass(100, 100); //st3
            psArg = new PointStruct(200, 200); //st4, overwritten value 12 in field x
        }
        static void TestArgByValue()
        {
            PointClass pc = new PointClass(1, 1);
            PointStruct ps = new PointStruct(2, 2);
            TestWithArgs(pc, ps);
            System.Console.WriteLine($"{pc}");
            System.Console.WriteLine($"{ps}");
        }
        static void TestArgByRef()
        {
            PointClass pc = new PointClass(1, 1);
            PointStruct ps = new PointStruct(2, 2);
            TestWithRef(ref pc, ref ps);
            System.Console.WriteLine($"{pc}");
            System.Console.WriteLine($"{ps}");
        }

        static void TestArgByOut()
        {
            PointClass pc;
            PointStruct ps;
            TestWithOut(out pc, out ps);
            System.Console.WriteLine($"{pc}");
            System.Console.WriteLine($"{ps}");
        }

        public static void TestEnumValue(State state)
        {
            switch (state)
            {
                case State.NotKnown:
                    System.Console.WriteLine("?!");
                    break;
                case State.New:
                    System.Console.WriteLine(state);
                    break;
                case State.Dead:
                    System.Console.WriteLine((int)state);
                    break;
                default:
                    System.Console.WriteLine($"default block for: {state}");
                    break;
            }

        }
        public static void EnumTest()
        {
            State state = State.New;
            TestEnumValue(state);
            TestEnumValue(State.NotKnown);
            TestEnumValue(State.Dead);
            TestEnumValue((State)11);
            TestEnumValue((State)100);  // there will be no error or exception
            System.Console.WriteLine(System.Enum.IsDefined(typeof(State), (short)100));
            System.Console.WriteLine($"Flags: {Direction.Down | Direction.Up}");
            System.Console.WriteLine($"Flags: {(Direction)15}");
            System.Console.WriteLine($"Flags: {(Direction)100}");
        }

        static void Main()
        {
            //DeclarationOfPoints();
            //TestArgByValue();
            //TestArgByRef();
            //TestArgByOut();
            EnumTest();
        }
    }
}
