﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebAppForEntityFrameworkDemo.Migrations
{
    public partial class QWE : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
