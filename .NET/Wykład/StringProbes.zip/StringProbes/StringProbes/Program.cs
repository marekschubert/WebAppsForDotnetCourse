﻿using System;

namespace StringProbes
{
    class Program
    {

        static void StringProbe1()
        {
            Console.WriteLine("it is a tab \t and newline \n second line");

        }

        static void StringProbe2()
        {
            Console.WriteLine(@"it is not a tab \t and not a newline \n this line
            quotation marks ""and then the second ""
end");

        }
        static void Main()
        {
            StringProbe1();
            StringProbe2();
        }
    }
}
