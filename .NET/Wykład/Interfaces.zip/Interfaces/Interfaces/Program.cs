﻿using System;

namespace Interfaces
{
    public interface ISound
    {
        string GiveVoice(int howMany);
    }

    public interface IWater
    {
        int HowManyFins { get; set; }
    }

    public interface IWaterLoud : ISound, IWater
    {
        // additional abstract methods
    }

    public class Cat : ISound
    {
        string ISound.GiveVoice(int howMany)
        {
            return "Miau";
        }
    }

    public class Dog : ISound
    {
        string ISound.GiveVoice(int howMany)
        {
            return "Hau";
        }
    }

    public class Diver : IWater
    {
        int IWater.HowManyFins { get; set; }
    }


    public class Whale : IWater
    {
        public int HowManyFins { get; set; }
    }

    public interface IShow
    {
        void ShowMe() => Console.WriteLine($"My type is {this.GetType().Name}");
    }

    public class ClassWithDefaultImpl : IShow
    {

    }

    class Program
    {
        public static void Sounds(ISound[] arr)
        {
            foreach (ISound sound in arr)
                Console.WriteLine(sound.GiveVoice(3));
        }


        public static void SoundsTest()
        {
            ISound[] arr = new ISound[] { new Dog(), new Cat(), new Cat() };
            Sounds(arr);
        }

        public static void WaterTest()
        {
            Diver diver = new Diver();
            Whale whale = new Whale();
            //diver.HowManyFins = 2;  // compilation error
            IWater waterFish = (IWater)diver;
            waterFish.HowManyFins = 2;
            whale.HowManyFins = 4;
        }

        public static void TestDefaultImpl()
        {
            ClassWithDefaultImpl cl = new ClassWithDefaultImpl();
            (cl as IShow).ShowMe();
        }


        static void Main()
        {
            SoundsTest();
            //TestDefaultImpl();
        }
    }
}
