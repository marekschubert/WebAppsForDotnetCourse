﻿using System;
using System.ComponentModel;

namespace ConsoleFirst
{
    class Program
    {

        public static void Test1()
        {
            System.Console.WriteLine("First line, full path");
            Console.WriteLine("second line");
        }

        public static void TestConcat()
        {
            Console.Write("polish letters - zażółć");
            Console.WriteLine(" jaźń");
        }


        public static void TestReadLine()
        {
            string firstStr;
            string secondStr;
            Console.Write("Input first string:");
            firstStr = Console.ReadLine();
            Console.WriteLine("Input second string:");
            secondStr = Console.ReadLine();
        }

        public static void TestCompositeFormatting()
        {
            string firstStr="a cat";
            string secondStr="Alice";
            Console.WriteLine("{1} has {0}. Again {1} has {0}.", firstStr, secondStr);
        }

        public static void TestStringInterpolation()
        {
            string firstStr = "a cat";
            string secondStr = "Alice";
            int value = 4;
            Console.WriteLine($"{secondStr} has {firstStr}");
            Console.WriteLine($"value = {value*4+value/4}");
        }

        /// <summary>
        /// Comment Test - only for presentation
        /// </summary>
        public static void TestComment()
        {
            string firstStr = "a cat"; // first test variable
            string secondStr = /* inner comment */ "Alice";
            /* comment block can 
              have many 
              lines */

            /* comment block  generated 
             * by VS adds
             * stars on lines' begin */
            int value = 4;
            Console.WriteLine($"{secondStr} has {firstStr}");
            Console.WriteLine($"value = {value * 4 + value / 4}");
            TestCommentXML();
        }

        /** 
         * <summary> <b>Empty method</b>.
         * This is only for presentation
         * </summary>
         **/
        public static void TestCommentXML()
        {

        }


        static void Main(string[] args)
        {

            //Test1();
            //TestConcat();
            //TestReadLine();
            //TestCompositeFormatting();
            //TestStringInterpolation();
        }
    }
}
