﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebAppRazorPagesStudents.Data;
using WebAppRazorPagesStudents.Models;

namespace WebAppRazorPagesStudents.Pages.Students
{
    public class DetailsModel : PageModel
    {
        private readonly WebAppRazorPagesStudents.Data.MyDbContext _context;

        public DetailsModel(WebAppRazorPagesStudents.Data.MyDbContext context)
        {
            _context = context;
        }

        public Student Student { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? Id { get; set; }
        //        public async Task<IActionResult> OnGetAsync(int? id)
        public async Task<IActionResult> OnGetAsync()
        {
            if (Id == null)
            {
                return NotFound();
            }

            Student = await _context.Student.FirstOrDefaultAsync(m => m.Id == Id);

            if (Student == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
