﻿using System;
using System.IO;
using System.Diagnostics;
using System.Reflection.Metadata.Ecma335;

namespace Exceptions
{
    public class MyTestException : Exception
    {

    }

    public class Program
    {

        public static void MakeException(int arg)
        {
            if (arg == 0)
                return;
            if (arg == 1)
                throw new IOException();
            if (arg == 2)
                throw new ArgumentOutOfRangeException();
            if (arg == 3)
                throw new MyTestException();
        }

        public static void TestException(int arg)
        {
            System.Console.WriteLine("Before try/catch/finally");
            try
            {
                System.Console.WriteLine("Before method call");
                MakeException(arg);
                System.Console.WriteLine("After method call");
            }
            catch(IOException)
            {
                System.Console.WriteLine("Problem with IO");
                System.Console.WriteLine("Exception solved !");
            }
            catch (ArgumentOutOfRangeException exp)
            {
                System.Console.WriteLine("Problem "+exp);
                System.Console.WriteLine("Dont know how to solve");
                throw; // rethrow exception
            }
            finally
            {
                System.Console.WriteLine("Anyway i will to this!");
            }
            System.Console.WriteLine("After try/catch/finally");
        }

        public static void TestWholeCases()
        {
            System.Console.WriteLine("----- case 0");
            TestException(0);
            System.Console.WriteLine("----- case 1");
            TestException(1);
            System.Console.WriteLine("----- case 2");
            try
            {
                TestException(2);
            }
            catch
            {
                System.Console.WriteLine("unhandled exception");
            }
            System.Console.WriteLine("----- case 3");
            try
            {
                TestException(3);
            }
            catch
            {
                System.Console.WriteLine("unhandled exception");
            }

        }


        public static void TestNotChecked()
        {
            int n = int.MaxValue;
            n = n + 1;
            System.Console.WriteLine(n);
        }
        public static void TestChecked()
        {
            checked
            {
                int n = int.MaxValue;
                n = n + 1;
                System.Console.WriteLine(n);
            }
        }

        public static int TestArrNormal()
        {
            int[] arr = new int[] {1,2 };
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
                sum += arr[i];
            return sum;
        }
        public static int TestArrException()
        {
            int[] arr = new int[] {1,2};
            int sum = 0;
            try
            {
                for (int i = 0; ; i++)
                    sum += arr[i];
            }
            catch(IndexOutOfRangeException )
            {
                // FIXME
            }
            return sum;
        }

        public static void TestTime(int howMany, Func<int> action)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            int global = 0;
            for (int i = 0; i < howMany; i++)
                global+=action();
            sw.Stop();
            Console.WriteLine($"result={global}, time elapsed={sw.Elapsed}.");
        }

        public static void TestTime()
        {
            int howMany = 1000;
            TestTime(howMany, TestArrNormal);
            TestTime(howMany, TestArrException);
        }

        public static void Main()
        {
            //TestWholeCases();
            //TestNotChecked();
            //TestChecked();
            TestTime();
        }
    }
}
