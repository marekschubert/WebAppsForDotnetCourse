﻿using System;


namespace Classes
{
	public partial class Probe
	{
		public int Age { get; set; } = 30;
		partial void ShowName()
		{
			Console.WriteLine($"name={Name}");
		}

		public void NormalMethod()
		{
			Console.WriteLine("Normal");
		}
	}

}
