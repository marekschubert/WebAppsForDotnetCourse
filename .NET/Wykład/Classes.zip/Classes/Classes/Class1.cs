﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Classes
{
	public partial class Probe
	{
		//partial void ShowAge()
		//{
		//	Console.WriteLine($"age={Age}");
		//}
	}
}
