﻿using System;

namespace Classes
{
    class Person1
    {
        public string name;
        public double salary;

        public void SalaryUp(int howMany)
        {
            if (howMany > 0)
                salary += howMany;
        }

        public void SalaryDown(int howMany)
        {
            if (howMany > 0)
                SalaryDownInner(howMany);
        }

        private void SalaryDownInner(int howMany)
        {
            if (howMany > 100)
                howMany = 100;
            salary -= howMany;
            if (salary < 1000)
                salary = 1000;
        }

        public string DescriptionStr()
        {
            return Program.GetSentence(this);
        }
    }

    class Person2
    {
        private string name;
        private double salary;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public double Salary
        {
            private set { if (value > 0) salary = value; else salary = 0; }
            get { return salary; }
        }
    }

    class Person3
    {
        private double salary /*= 12000.4*/;
        public string Name { get; set; } /*= "Kowalski";*/

        public double Salary
        {
            private set { if (value > 0) salary = value; else salary = 0; }
            get { return salary; }
        }
        // = 1234.5; // compilation error
    }

    class Person4
    {
        public string Name { get; set; }
        public double Salary { get; set; }

        public Person4(string name, double salary = 3000)
        {
            Name = name;
            Salary = salary;
        }
        public Person4(int salary, string name) : this(name, salary)
        {
            // ewentualne kolejne instrukcje
        }

    }

    class Person5
    {
        public string Name { get; set; }
        public double Salary { get; set; }
        public int Age { get; set; }

        public Person5(string name, double salary, int age)
        {
            Name = name;
            Salary = salary;
            Age = age;
        }

        public void Deconstruct(out string name, out double salary, out int age)
        {
            (name, salary, age) = (Name, Salary, Age);
        }
        public void Deconstruct(out string name, out double salary)
        {
            (name, salary) = (Name, Salary);
        }

    }

    class CloneCounter
    {
        const int START = 1;
        readonly int localStart;
        static int lastNumber = START;
        static string globalName;
        static CloneCounter()
        {
            globalName = "Global counter at " + DateTime.Now;
            //START = 2;
        }
        public CloneCounter()
        {
            localStart = lastNumber;
            lastNumber++;
        }
    }


    public static class MyStringExtension
    {
        public static string AddStars(this string str, int howMany)
        {
            while (howMany > 0)
            {
                str += "*";
                howMany--;
            }
            return str;
        }
    }

    public partial class Probe
    {
        public string Name { get; set; } = "Kowalski";


        partial void ShowName();
        partial void ShowAge();

        public void ShowIt()
        {
            NormalMethod();
            Console.WriteLine($"Before {Age}");
            ShowName();
            ShowAge();
            Console.WriteLine("After");

        }

    }
    class Program
    {
        public static string GetSentence(Person1 person)
        {
            return $"{person.name} has a salary of {person.salary} ";
        }
        static void Person1Test()
        {
            Person1 person = new Person1();
            person.name = "Kowalski";
            person.salary = 3000;
            person.SalaryUp(100);
            //person.SalaryDownInner(100);
            Console.WriteLine($"name={person.name}, salary={person.salary}");
        }

        static void Person3Test()
        {
            Person3 person = new Person3();
            person.Name = "Kowalski";
            //person.Salary = 3000;
            person.Name += "-Nowak";
            Console.WriteLine($"name={person.Name}, salary={person.Salary}");
        }
        static void Person4Test()
        {
            // Person4 person = new Person4();
            Person4 person = new Person4("Kowalski");
            person.Salary += 500;
            Console.WriteLine($"name={person.Name}, salary={person.Salary}");
        }

        static void Person4Test2()
        {
            // Person4 person = new Person4();
            int value = 100;
            Person4 person = new Person4("Kowalski") { Salary = 1400 + value, Name = "Nowak" };
            //person.Salary = 1400;
            //...
            Console.WriteLine($"name={person.Name}, salary={person.Salary}");
        }

        static void Person5Test()
        {
            Person5 person = new Person5("Kowalski", 2500, 33);
            person.Deconstruct(out _, out double salary1, out int age1);
            string name2;
            double salary2;
            person.Deconstruct(out name2, out salary2);
            (name2, salary2) = person; // to samo
            Console.WriteLine($"name={name2}, salary={salary2}");
        }



        static void AddStarsTest()
        {
            string line = "any word ";
            Console.WriteLine(MyStringExtension.AddStars(line, 5));
            Console.WriteLine(line.AddStars(5));
            Console.WriteLine("this is also possible".AddStars(3));
        }


        static void PartialClassTest()
        {
            Probe probe = new Probe();
            probe.ShowIt();
        }
        static void Main()
        {
            Person4Test2();
            AddStarsTest();
            PartialClassTest();
        }
    }

}
