﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAppForRazorDemo.DataContext;
using WebAppForRazorDemo.ViewModels;

namespace WebAppForRazorDemo.Controllers
{
    public class StudentController : Controller
    {
        // remeber the context for an action
        private IDataContext _dataContext;

        // injection of IDataContext 
        public StudentController(IDataContext dataContext)
        {
            this._dataContext = dataContext;
        }

        // GET: StudentController
        public ActionResult Index()
        {
            return View(_dataContext.GetStudents());// addded parameter
        }

        public ActionResult AnotherIndex() // new action added manually
        {
            return View(_dataContext.GetStudents()); 
        }
        //[Route("newDetails/{id}", Name ="newDetailsRoute")]
        // GET: StudentController/Details/5
        public ActionResult Details(int id)
        {
            return View(_dataContext.GetStudent(id)); // added parameter
        }

        // GET: StudentController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StudentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(StudentViewModel student) // change of parameter, data binding
        {
            try
            {
                if (ModelState.IsValid)                // added
                    _dataContext.AddStudent(student);  // added
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Edit/5
        public ActionResult Edit(int id)
        {
            return View(_dataContext.GetStudent(id)); // added parameter
        }

        // POST: StudentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, StudentViewModel student) // change the second parameter
        {

            try
            {
                if (ModelState.IsValid)
                {
                    student.Id = id; // added
                    _dataContext.UpdateStudent(student); //added
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Delete/5
        public ActionResult Delete(int id)
        {
            return View(_dataContext.GetStudent(id)); // zmiana
        }

        // POST: StudentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection) //musi być inny nagłowek metody, zostaje
        {
            try
            {
                _dataContext.RemoveStudent(id); // zmiana
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
