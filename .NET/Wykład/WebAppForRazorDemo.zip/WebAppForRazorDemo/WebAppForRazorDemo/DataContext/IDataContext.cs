﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAppForRazorDemo.ViewModels;

namespace WebAppForRazorDemo.DataContext
{
    public interface IDataContext
    {
        List<StudentViewModel> GetStudents();
        StudentViewModel GetStudent(int id);
        void AddStudent(StudentViewModel person);
        void RemoveStudent(int id);
        void UpdateStudent(StudentViewModel person);

    }
}
