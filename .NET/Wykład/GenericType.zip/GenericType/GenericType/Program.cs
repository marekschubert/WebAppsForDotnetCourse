﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace GenericType
{

    public class Pair<T, S>
    {
        public T First { get; set; }
        public S Second { get; set; }
        public Pair(T first, S second)
        {
            First = first;
            Second = second;
        }

        public void set(T first, S second)
        {
            First = first;
            Second = second;
        }

        public override string ToString()
        {
            return $"({First},{Second})";
        }
    }

    class Program
    {

        public static void StackTest()
        {
            Stack<int> stackInt = new Stack<int>();
            Stack<Point> stackPoint = new Stack<Point>();
            Stack<object> stackObject = new Stack<object>();

            stackInt.Push(4);
            stackInt.Push(5);
            stackInt.Push(6);
            Console.WriteLine(stackInt.Pop());
            Console.WriteLine(stackInt.Pop());
            Console.WriteLine(stackInt.Pop());

            stackPoint.Push(new Point(2, 3));
            stackPoint.Push(new Point());
            stackPoint.Push(new Point(1, 1));
            Point p1 = stackPoint.Pop();
            Console.WriteLine(p1);
            Console.WriteLine(stackPoint.Pop());
            Console.WriteLine(stackPoint.Pop());

            stackObject.Push(new Point(2, 3));
            stackObject.Push(2);
            stackObject.Push(new Point());

            p1 = (Point)stackObject.Pop(); // it must be casted
            int x = (int)stackObject.Pop();
            x = (int)stackObject.Pop(); // there will be an exception, there is Point not int
        }

        public static void PairTest()
        {
            Pair<int, string> para = new Pair<int, string>(2, "one");
            para.First = 1;
            Console.WriteLine(para);
            Stack<Pair<int, string>> pairStack = new Stack<Pair<int, string>>();
            pairStack.Push(para);
            pairStack.Push(new Pair<int, string>(2, "two"));
            Console.WriteLine(pairStack.Pop());
            Console.WriteLine(pairStack.Pop());
            Console.WriteLine(pairStack.Count);
        }

        static void Main(string[] args)
        {
            //StackTest();
            PairTest();
        }
    }
}
