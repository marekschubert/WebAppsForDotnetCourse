﻿using System;

namespace VariablesEtc
{
    class Program
    {

        static void Variables()
        {
            int xyz = 10, abc;
            double a = 2.3;
            //xyz = abc; // compile error: variable abc is uninitialized, it cannot be on the right side of =
            abc = xyz;
            int b = 23 * abc - 4;
            a += 3;
        }

        static void Literals()
        {
            int x = 0b01010;
            long a = 1_234_567_890; //separators using
            float b = 1.0f; // without 'f' compilation error
            float c = 123.45e10f;
            decimal d = 123456789;
            System.Console.WriteLine($"d = {a}");
            System.Console.WriteLine($"d = {a:X}");
        }

        static void StringExample()
        {
            string str1 = "abc Value";
            str1 = str1.ToUpper();
            System.Console.WriteLine(str1);
            str1 = string.Concat(str1, "=xyz");
            System.Console.WriteLine(str1);
            string str2 = "some lines";
            str2 += " and" + " a word";
            System.Console.WriteLine(str2);
        }

        static void Castings()
        {
            int a = 1234;
            uint b = (uint)a;
            long c = a;
            c = b;
            float x = c;
            System.Console.WriteLine("x=" + x);
            double d = x;
            d = 20e100;
            x = (float)d;
            System.Console.WriteLine("d=" + d);
            System.Console.WriteLine("x=" + x);
        }

        static void Nullable()
        {
            int x = 1;
            //x = null; // compile error
            int? y = 2;
            y = null;
            System.Console.WriteLine(x == y);
            y = 1;
            System.Console.WriteLine(x == y);
        }

        static void Var()
        {
            var x = 1 + 3;
            var str = "sequence of characters";
            var str2 = str.ToUpper();
        }

        static void Anonymous()
        {
            var book1 = new { title = "The War of the Worlds", year = 1898 };
            var book2 = new { title = "The Hobbit or There and Back Again", year = 1937 };
            System.Console.WriteLine($"{book1.title} from year {book1.year}");
            System.Console.WriteLine($"{book2.title} from year {book2.year}");
        }

        static void Tuples()
        {
            (string name1, string author1, double price1) = ("Hothouse", "Brian W. Aldiss", 120.0);
            System.Console.WriteLine($"Book {name1} by  {author1} for {price1} zł.");

            string name2;
            string author2;
            double price2;
            (name2, author2, price2) = ("Hothouse", "Brian W. Aldiss", 120.0);
            System.Console.WriteLine($"Book {name2} by  {author2} for {price2} zł.");

            (var name3, var author3, var price3) = ("Hothouse", "Brian W. Aldiss", 120.0);
            System.Console.WriteLine($"Book {name3} by  {author3} for {price3} zł.");

            var (name4, author4, price4) = ("Hothouse", "Brian W. Aldiss", 120.0);
            System.Console.WriteLine($"Book {name4} by  {author4} for {price4} zł.");

            (string Name, string Author, double Price) bookInfo5 = ("Hothouse", "Brian W. Aldiss", 120.0);
            System.Console.WriteLine($"Book {bookInfo5.Name} by  {bookInfo5.Author} for {bookInfo5.Price} zł.");

            var bookInfo6 = (Name: "Hothouse", Author: "Brian W. Aldiss", Price: 120.0);
            System.Console.WriteLine($"Book {bookInfo6.Name} by  {bookInfo6.Author} for {bookInfo6.Price} zł.");

            var bookInfo7 = ("Hothouse", "Brian W. Aldiss", 120.0);
            System.Console.WriteLine($"Book {bookInfo7.Item1} by  {bookInfo7.Item2} for {bookInfo7.Item3} zł.");

            //            var bookInfo8 = (Name: "Hothouse", Author: "Brian W. Aldiss", Price: 120.0);
            //            System.Console.WriteLine($"Book {bookInfo8.Item1} by  {bookInfo8.Item2} for {bookInfo8.Item3} zł.");

            var bookInfo8 = (name: "Hothouse", author: "Brian W. Aldiss", price: 120.0);
            System.Console.WriteLine($"Book {bookInfo8.name} by  {bookInfo8.author} for {bookInfo8.price} zł.");

            (string name9, _, double price9) = ("Hothouse", "Brian W. Aldiss", 120.0);
            System.Console.WriteLine($"Book {name9} for {price9} zł.");

            string nameX = "Hothouse";
            string authorX = "Brian W. Aldiss";
            double priceX = 120.0;
            var bookInfoX = (nameX, authorX, priceX);
            System.Console.WriteLine($"Book {bookInfoX.nameX} by  {bookInfoX.authorX} for {bookInfoX.Item3} zł.");

        }

        static void Arrays()
        {
            int[,] cells = new int[2, 3] { { 0, 1, 2 }, { 3, 4, 5 } };
            int[][] arr = { new int[] { 0, 1, 2 }, new int[] { 3, 4 }, new int[] { 1 } };

            int[,][,] arrSpec;

        }


        static void DoubleVsDecimal()
        {
            double x = 0.1;
            double xx = x + x + x;

            Console.WriteLine("{0:R}", xx); // 0,30000000000000004

            decimal y = 0.1M;
            decimal yy = y + y + y;

            Console.WriteLine("{0}", yy);  // 0,3
        }
        static void Main(string[] args)
        {
            DoubleVsDecimal();
            Variables();
            Literals();
            StringExample();
            Castings();
            Nullable();
            Anonymous();
            Tuples();
        }
    }

}
