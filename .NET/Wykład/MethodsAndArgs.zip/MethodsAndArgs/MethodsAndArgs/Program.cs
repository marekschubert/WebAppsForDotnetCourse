﻿using System;
using System.Drawing; // for Point

namespace MethodsAndArgs
{
    class Program
    {
        static void DiffForwardingInt(int a, ref int b, out int c)
        {
            a++;
            b++;
            //c++;  //error, c can be not initialized
            c = 50;  // without initialization - compile error
        }

        static void DiffForwardingIntTest()
        {
            int x = 10;
            int y = 100;
            int z; // // can be not initialized
            Console.WriteLine($"x={x}, y={y}");
            DiffForwardingInt(x, ref y, out z);
            Console.WriteLine($"x={x}, y={y},z={z}");
        }

        static void DiffForwardingStruct(Point p1, ref Point p2, out Point p3)
        {
            p1.X++;
            p2.X++;
            p1 = new Point(5, 5);
            p2 = new Point(6, 6);
            p3 = new Point(7, 7);
        }

        static void DiffForwardingStructTest()
        {
            Point pkt1 = new Point(1, 1);
            Point pkt2 = new Point(10, 10);
            Point pkt3;
            Console.WriteLine($"pkt1={pkt1}, pkt2={pkt2}");
            DiffForwardingStruct(pkt1, ref pkt2, out pkt3);
            Console.WriteLine($"pkt1={pkt1}, pkt2={pkt2}, pkt3={pkt3}");
        }

        class CPoint
        {
            public int x, y;
            public CPoint(int x, int y) { this.x = x; this.y = y; }
            public override string ToString()
            {
                return $"{{x={x},y={y}}}";
            }
        }

        static void DiffForwardingRefType(CPoint p1, ref CPoint p2, out CPoint p3)
        {
            p1.x++;
            p2.x++;
            p1 = new CPoint(5, 5);
            p2 = new CPoint(6, 6);
            p3 = new CPoint(7, 7);
        }
        static void DiffForwardingRefTypeTest()
        {
            CPoint pkt1 = new CPoint(1, 1);
            CPoint pkt2 = new CPoint(10, 10);
            CPoint pkt3;
            Console.WriteLine($"pkt1={pkt1}, pkt2={pkt2}");
            DiffForwardingRefType(pkt1, ref pkt2, out pkt3);
            Console.WriteLine($"pkt1={pkt1}, pkt2={pkt2}, pkt3={pkt3}");
        }

        static string ForwardingParams(string name, params int[] tab)
        {
            int sum = 0;
            foreach (int value in tab)
            {
                sum += value;
            }
            return name + "=" + sum;
        }


        static void ForwardingParamsTest()
        {
            int[] tab = new int[] { 1, 2, 3, 4 };
            Console.WriteLine(ForwardingParams("as a variable tab: ", tab));
            Console.WriteLine(ForwardingParams("as an array: ", new int[] { 1, 2, 3, 4 }));
            Console.WriteLine(ForwardingParams("as parameters: ", 1, 2, 3, 4));
        }


        static void OptionalParameters(int number, string name, int marker = 0, string ident = "noValue")
        {
            Console.WriteLine($"{number},{name},{marker},{ident}");
        }



        static void OptionParametersTest()
        {
            OptionalParameters(1, "Kaczyński", 2, "Nadprezydent");
            OptionalParameters(2, "Nowak", 1);
            //OptionalParameters(3, "Kowalski");
        }

        static void NamedArgumentsTest()
        {
            OptionalParameters(5, marker: 5, name: "Suweren");
            OptionalParameters(ident: "rycerz", name: "Zawisza Czarny", number: 6);
            OptionalParameters(7, "Żuk", 0, "robaczek"); // trzeba "pamiętać" ile wynosi pierwszy domyślny parametr
            OptionalParameters(7, "Żuk", ident: "robaczek");
        }

        static void OptionalParameters(int nr, string name, int smt = 5)
        {
            Console.WriteLine($"nr={nr},name={name},cos={smt}");
        }

        static void OverloadedMethodsTest()
        {
            OptionalParameters(1, "Kaczyński", 2, "Nadprezydent");
            OptionalParameters(2, "Nowak", 1);
            //OptionalParameters(3, "Kowalski");
            OptionalParameters(number: 3, "Kowalski"); // after adding overloaded method
            OptionalParameters(nr: 3, "Kowalski"); // after adding overloaded method
        }

        static void Main()
        {
            DiffForwardingIntTest();
            DiffForwardingStructTest();
            DiffForwardingRefTypeTest();
            ForwardingParamsTest();
            OptionParametersTest();
            NamedArgumentsTest();
            OverloadedMethodsTest();
        }
    }

}
