﻿using System;
using System.Collections.Generic;

namespace Generic
{
    public interface IPair<T, S>
    {
        public T First { get; set; }
        public S Second { get; set; }
        public void Set(T first, S second);
    }

    public class GenPair<T, S> : IPair<T, S>
    {
        public T First { get; set; }
        public S Second { get; set; }
        public GenPair(T first, S second)
        {
            First = first;
            Second = second;
        }
        public void Set(T first, S second)
        {
            First = first;
            Second = second;
        }
        public override string ToString()
        {
            return $"({First},{Second})";
        }
    }
    public class PairIntString : IPair<int, string>
    {
        public int First { get; set; }
        public string Second { get; set; }
        public PairIntString(int first, string second)
        {
            First = first;
            Second = second;
        }
        public void Set(int first, string second)
        {
            First = first;
            Second = second;
        }
        public override string ToString()
        {
            return $"({First},{Second})";
        }
    }
    class Program
    {
        public static T Max<T>(T[] tab) where T : IComparable<T>
        {
            T max = tab[0];
            for (int i = 1; i < tab.Length; i++)
            {
                if (tab[i].CompareTo(max) > 0)
                    max = tab[i];
            }
            return max;
        }

        public static void QueueProbe()
        {
            Queue<string> queueS = new Queue<string>();
            Console.WriteLine("Queue:");
            queueS.Enqueue("one");
            queueS.Enqueue("two");
            queueS.Enqueue("three");
            foreach (string s in queueS)
                Console.WriteLine(s);
            while (queueS.Count != 0)
                Console.WriteLine(queueS.Dequeue());
            Console.WriteLine("Queue after dequeu:");
            foreach (string s in queueS)
                Console.WriteLine(s);
        }

        public static void DictionaryProbe()
        {
            var dict = new Dictionary<int, string>();
            dict.Add(5, "Aleksy");
            dict.Add(3, "John");
            dict.Add(8, "Proxy");
            dict.Add(4, "cat");
            Console.WriteLine("dictionary:");
            foreach (var elem in dict)
                Console.WriteLine(elem);
            Console.WriteLine("keys:");
            foreach (var elem in dict.Keys)
                Console.WriteLine(elem);
            Console.WriteLine("access to one elem by a key (very fast):");
            Console.WriteLine(dict.GetValueOrDefault(8));
            Console.WriteLine(dict.GetValueOrDefault(1));
            Console.WriteLine("Remove() returns:" + dict.Remove(5));
            Console.WriteLine("TryAdd() returns:" + dict.TryAdd(8, "nonproxy"));
        }
        public static void CollectionProbe()
        {
            //QueueProbe();
            DictionaryProbe();
        }
        static void Main()
        {
            Console.WriteLine(Max(new int[] { 2, 3, 6, 4, 1 }));
            Console.WriteLine(Max(new string[] { "alice", "has", "a cat" }));
            CollectionProbe();
        }
    }
}
