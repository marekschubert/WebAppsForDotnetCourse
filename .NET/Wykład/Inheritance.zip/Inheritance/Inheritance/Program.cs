﻿using System;
using System.Diagnostics;

namespace Inheritance
{
    class Person
    {
        public string Name { get; set; }
        public int YearOfBirth { get; set; }
        protected string Info { get; set; }
        private string hidden;

        public Person(string name, int year, string info, string hidden)
        {
            Name = name;
            YearOfBirth = year;
            Info = info;
            this.hidden = hidden;
        }

        public virtual void showAll()
        {
            Console.WriteLine($"{Name}, {YearOfBirth}, {Info},{hidden}");
        }

    }

    class Worker : Person
    {
        public double Salary { get; set; }
        public Worker(string name, int year, string info, double salary) : base(name, year, info, "worker")
        {
            Salary = salary;
        }

        public void ShowProtected()
        {
            Console.WriteLine($"{Info}");
            //Console.WriteLine($"{hidden}");
        }


        public override void showAll()
        {
            base.showAll();
            Console.WriteLine($"{Salary}");
        }
    }

    public class ClassA
    {
        public void DisplayName()
        {
            Console.WriteLine("Class A");
        }
    }
    public class ClassB : ClassA
    {
        // warning that B is hiding an inherited method recommends using the word new
        public virtual void DisplayName()
        {
            Console.WriteLine("Class B");
        }
    }

    public class ClassC : ClassB
    {
        public override void DisplayName()
        {
            Console.WriteLine("Class C");
        }
    }

    public class ClassD : ClassC
    {
        public new void DisplayName()
        {
            Console.WriteLine("Class D");
        }
    }

    public abstract class Animal
    {
        string Name { get; set; }
        public Animal(string name)
        {
            Name = name;
        }

        public abstract string GiveVoice(int howMany);
    }

    public class Cat : Animal
    {
        public string Color { get; set; }
        public Cat(string name, string hair) : base(name)
        {
            Color = hair;
        }
        public override string GiveVoice(int howMany)
        {
            return "Miau";
        }
    }

    public class Dog : Animal
    {
        public int Height { get; set; }
        public Dog(string name, int height) : base(name)
        {
            Height = height;
        }
        public override string GiveVoice(int n)
        {
            string retStr = "";
            for (int i = 0; i < n; i++)
                retStr += "hau, ";
            return retStr;
        }
    }


    class PersonPure
    {
        public string Name { get; set; }
        public int Salary { get; set; }
        public PersonPure(string name, int salary) { Name = name; Salary = salary; }
    }
    class PersonRich
    {
        public string Name { get; set; }
        public int Salary { get; set; }

        public PersonRich(string name, int salary) { Name = name; Salary = salary; }

        public override bool Equals(object obj)
        {
            PersonRich p = obj as PersonRich;
            return p == null ? false : this.Name.Equals(p.Name);
        }
        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }

        public override string ToString()
        {
            return $"PersonRich(Name={Name}, Salary={Salary})";
        }
    }

    class Program
    {
        public static void PersonTest()
        {
            Person person = new Person("Kowal", 1999, "all is OK", "agent");
            //person.Info = "anything";
            //person.hidden = "anything";
            person.Name = "Schmidt";
            person.showAll();
            Worker worker = new Worker("Nowak", 2000, "good person", 3000);
            worker.Name = "Olaf";
            //worker.Info = "anything";
            worker.showAll();
            worker.ShowProtected();
        }

        public static void InheritanceTest()
        {
            ClassD objD = new ClassD();
            ClassA objA = objD;
            ClassB objB = objD;
            ClassC objC = objD;

            objD.DisplayName();
            objC.DisplayName();
            objB.DisplayName();
            objA.DisplayName();
        }

        public static void AnimalTest()
        {
            //Animal animal = new Animal();
            Animal zw1 = new Cat("Mrau", "white");
            Animal zw2 = new Dog("Dingo", 50);
            Console.WriteLine(zw1.GiveVoice(2));
            Console.WriteLine(zw2.GiveVoice(2));


        }

        public static void TestBaseAndPolimorphizm()
        {
            Person person = new Person("Kowal", 1999, "all is OK", "agent");
            Worker worker = new Worker("Nowak", 2000, "good person", 3000);
            person.showAll();
            worker.showAll();
            person = worker;
            Console.WriteLine("after assignment person = worker");
            person.showAll();
        }


        public static void AllVoices(Animal[] arrAnim, int howMany)
        {
            foreach (Animal zw in arrAnim)
                Console.WriteLine(zw.GiveVoice(howMany));
        }
        public static void PolimorphizmTest()
        {
            Animal[] arr = { new Cat("Mrau", "white"),
                new Dog("Dingo", 50),
                new Dog("Rex", 30),
                new Cat("Garfild", "red")};
            AllVoices(arr, 4);
        }

        public static void CheckPerson(Person pers)
        {
            if (pers is Worker)
                System.Console.WriteLine("This is a worker");
            else
                System.Console.WriteLine("This is NOT a worker");
        }

        public static void CheckAsWorker(Person pers)
        {
            Worker man = pers as Worker;
            if (man != null)
                System.Console.WriteLine($"Salary={man.Salary}");
            else
                System.Console.WriteLine("null");
        }

        public static void PersonPureRich()
        {
            PersonPure pp1 = new PersonPure("Nowak", 2000);
            PersonPure pp2 = new PersonPure("Nowak", 2000);
            PersonRich pr1 = new PersonRich("Kowal", 3000);
            PersonRich pr2 = new PersonRich("Kowal", 5555);
            System.Console.WriteLine(pp1);
            System.Console.WriteLine(pr1);
            System.Console.WriteLine(pp1.Equals(pp2));
            System.Console.WriteLine(pr1.Equals(pr2));
            System.Console.WriteLine($"{pp1.GetHashCode()} != {pp2.GetHashCode()}");
            System.Console.WriteLine($"{pr1.GetHashCode()} == {pr2.GetHashCode()}");
        }


        static void testIsAndAs()
        {
            Person person = new Person("Kowal", 1999, "all is OK", "agent");
            Worker worker = new Worker("Nowak", 2000, "good person", 3000);
            CheckPerson(person);
            CheckPerson(worker);
            CheckAsWorker(person);
            CheckAsWorker(worker);
            worker = (Worker)person;
        }


        static void WrongCastingException()
        {
            System.Console.WriteLine("Start: " + nameof(WrongCastingException));
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            const int HOWMANY = 1000;
            for (int i = 0; i < HOWMANY; i++)
            {
                Person person = new Person("Kowal", 1999, "all is OK", "agent");
                try
                {
                    Worker worker = (Worker)person;
                    System.Console.WriteLine(worker);
                }
                catch (InvalidCastException)
                {
                    // ignore...
                }
            }
            stopWatch.Stop();
            // Get the elapsed time as a TimeSpan value.
            TimeSpan ts = stopWatch.Elapsed;
            System.Console.WriteLine("Finish: " + ts.TotalSeconds + "s");
        }
        static void WrongCastingIs()
        {
            System.Console.WriteLine("Start: " + nameof(WrongCastingIs));
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            const int HOWMANY = 1000;
            for (int i = 0; i < HOWMANY; i++)
            {
                Person person = new Person("Kowal", 1999, "all is OK", "agent");
                if (person is Worker)
                {
                    Worker worker = (Worker)person;
                    System.Console.WriteLine(worker);
                }
            }
            stopWatch.Stop();
            // Get the elapsed time as a TimeSpan value.
            TimeSpan ts = stopWatch.Elapsed;
            System.Console.WriteLine("Finish: " + ts.TotalSeconds + "s");

        }

        static void Main(string[] args)
        {
            PersonTest();
            InheritanceTest();
            TestBaseAndPolimorphizm();
            AnimalTest();
            PolimorphizmTest();
            testIsAndAs();
            PersonPureRich();
            WrongCastingIs();
            WrongCastingException();
        }
    }
}

