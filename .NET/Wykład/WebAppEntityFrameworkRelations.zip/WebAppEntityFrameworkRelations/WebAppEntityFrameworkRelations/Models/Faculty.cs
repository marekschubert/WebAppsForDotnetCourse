﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppEntityFrameworkRelations.Models
{
    public class Faculty
    {
        public int FacultyId { get; set; }
        [Required]
        [MaxLength(40)]
        public string FacultyName { get; set; } // can be Name

        public ICollection<Student> Student { get; set; }
    }
}
