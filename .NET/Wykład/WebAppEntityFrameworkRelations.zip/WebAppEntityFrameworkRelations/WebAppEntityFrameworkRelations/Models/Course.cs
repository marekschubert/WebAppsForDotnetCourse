﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppEntityFrameworkRelations.Models
{
    public class Course
    {
        public int CourseId { get; set; }

        [Required]
        [MaxLength(40)]
        public string CourseName { get; set; }

        public ICollection<CourseStudent> CourseStudents { get; set; }
    }
}
