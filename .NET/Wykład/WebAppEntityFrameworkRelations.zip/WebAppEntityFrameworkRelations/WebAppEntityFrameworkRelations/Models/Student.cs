﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppEntityFrameworkRelations.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        [Required]
        [MaxLength(40)]
        public string LastName { get; set; }

        public List<CourseStudent> CourseStudents { get; set; } // name can be Course


       public int FacultyId { get; set; }
       public Faculty Faculty { get; set; }  // name can be Faculty
    }
}
