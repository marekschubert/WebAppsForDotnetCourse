﻿//#define VERBOSE
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace ControlStatements
{
    class Program
    {
        static int orderCounter = 0;

        static int A()
        {
            orderCounter++;
            Console.WriteLine($"A() - >orderCounter={orderCounter}");
            return 4;
        }
        static int B()
        {
            orderCounter++;
            Console.WriteLine($"B() -> orderCounter={orderCounter}");
            return 5;
        }
        static int C()
        {
            orderCounter++;
            Console.WriteLine($"C() -> orderCounter={orderCounter}");
            return 6;
        }

        static void OrderInExpression()
        {
#if VERBOSE
            Console.WriteLine("Testing "+nameof(OrderInExpression));
#endif
            Console.WriteLine(A() + B() * C());
        }

        static void PostPre()
        {
            #region preincrementaion
            int a = 3;
            int b = ++a;
            Console.WriteLine($"a={a}, b={b}");
            #endregion
            #region postincrementaion
            a = 3;
            b = a++;
            Console.WriteLine($"a={a}, b={b}");
            #endregion
        }

        static void CollatzProblem(int n)
        {
            if (n < 1) return;
            while (n != 1)
            {
                Console.Write(n + " ");
                if (n % 2 == 0)
                    n /= 2;
                else
                    n = 3 * n + 1;
            }
            Console.WriteLine(n);
        }

        static void CollatzProblemTest()
        {
            CollatzProblem(17);
            CollatzProblem(15);
            CollatzProblem(-5);
        }

        static int BinarySearch(int[] arr, int value)
        {
            int minIdx = 0;
            int maxIdx = arr.Length - 1;
            do
            {
                int midIdx = (minIdx + maxIdx) / 2;
                if (arr[midIdx] == value)
                    return midIdx;
                else if (arr[midIdx] < value)
                    minIdx = midIdx + 1;
                else
                    maxIdx = midIdx - 1;
            }
            while (minIdx < maxIdx);
            return minIdx;
        }
        static void BinarySearchTest()
        {
            Console.WriteLine(BinarySearch(new int[] { 1, 3, 5, 7, 9, 11, 13, 15 }, 5));
            Console.WriteLine(BinarySearch(new int[] { 1, 3, 5, 7, 9, 11, 13, 15 }, 15));
            Console.WriteLine(BinarySearch(new int[] { 1, 3, 5, 7, 9, 11, 13, 15 }, 1));
            Console.WriteLine(BinarySearch(new int[] { 1, 3, 5, 7, 9, 11, 13, 15 }, 0));
            Console.WriteLine(BinarySearch(new int[] { 1, 3, 5, 7, 9, 11, 13, 15 }, 8));
        }

        static void ForLoopTest()
        {
            int[] arr = { 1, 3, 5, 7 };
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
                sum += arr[i];
            Console.WriteLine(sum);
            sum = 0;
            foreach (int value in arr)
                sum += value;
            Console.WriteLine(sum);
            for (int i = 0; i < arr.Length; i++)
                arr[i]++;
            //foreach (int value in arr)
            //    value++; // error: variable - constant in body of foreach loop
        }

        static void SwitchInstruction(string line)
        {
            switch (line)
            {
                case "Good":
                case "OK":
                    Console.WriteLine("All right");
                    break;
                case "Super":
                    Console.Write("Extra - ");
                    goto case "OK";
                case "Can be":
                    Console.WriteLine("It is fine");
                    break;
                default:
                    Console.WriteLine("I don't understand...");
                    break;
            }

        }

        static void SwitchInstructionTest()
        {
            SwitchInstruction("Good");
            SwitchInstruction("Can be");
            SwitchInstruction("So-so");
        }

        static bool IsText(string str)
        {
            return (str?.Length ?? 0) != 0;
        }

        static void ShortIfsTest()
        {
            Random rnd = new Random();
            int x = rnd.Next(100);
            string str = x < 50 ? "to low" : "to high";
            Console.WriteLine($"drawn {x} so {str}");
            Console.WriteLine($"is a text: {IsText(null)}");
            Console.WriteLine($"is a text: {IsText("")}");
            Console.WriteLine($"is a text: {IsText("it is")}");
        }

        public static string MyBinary(int value)
        {
            const int len = 32;
            string ret = Convert.ToString(value, 2);
            while (ret.Length < len)
                ret = "0" + ret;
            return ret;
        }

        static void BinaryOperators()
        {
            int value = 10;
            int mask = 3;
            Console.WriteLine($"value = {MyBinary(value)}");
            Console.WriteLine($"mask  = {MyBinary(mask)}");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine($"v | m = {MyBinary(value | mask)}");
            Console.WriteLine($"v & m = {MyBinary(value & mask)}");
            Console.WriteLine($"v ^ m = {MyBinary(value ^ mask)}");
            Console.WriteLine($"~v    = {MyBinary(~value)}");
            Console.WriteLine($"v >> 2= {MyBinary(value >> 2)}");
            Console.WriteLine($"v << 2= {MyBinary(value << 2)}");
        }

        static void SwitchTest2()
        {
            int[] values = { 2, 4, 6, 8, 10 };
            ShowCollectionInformation(values);

            var names = new List<string>();
            names.AddRange(new string[] { "Adam", "Abigail", "Bertrand", "Bridgette" });
            ShowCollectionInformation(names);

            List<int> numbers = null;
            ShowCollectionInformation(numbers);
        }

        private static void ShowCollectionInformation<T>(T coll)
        {
            switch (coll)
            {
                case Array arr:
                    Console.WriteLine($"An array with {arr.Length} elements.");
                    break;
                case IEnumerable<int> ieInt:
                    Console.WriteLine($"Average: {ieInt.Average(s => s)}");
                    break;
                case System.Collections.IList list:
                    Console.WriteLine($"{list.Count} items");
                    break;
                case IEnumerable ie:
                    string result = "";
                    foreach (var e in ie)
                        result += $"{e} ";
                    Console.WriteLine(result);
                    break;
                case null:
                    Console.WriteLine("Null passed to this method.");
                    break;
                default:
                    Console.WriteLine($"A instance of type {coll.GetType().Name}");
                    break;
            }
        }

        static void Main()
        {
            CollatzProblemTest();
            BinarySearchTest();
            ForLoopTest();
            SwitchInstructionTest();
            ShortIfsTest();
            BinaryOperators();
            OrderInExpression();
            SwitchTest2();
            PostPre();
        }
    }
}
