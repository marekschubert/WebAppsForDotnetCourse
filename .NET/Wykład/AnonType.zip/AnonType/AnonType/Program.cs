﻿using System;
using System.Net.Cache;

namespace AnonType
{
    class Program
    {
        static void AnonTypeTest()
        {
            var person = new
            {
                Name = "Smidth",
                Age = 30
            };
            System.Console.WriteLine(person.Age);
            System.Console.WriteLine(person);
        }

        static void AnonTypeArg(dynamic arg)
        {
            System.Console.WriteLine(arg.Age);
            System.Console.WriteLine(arg.Salary);
        }

        static void AnonTypeArgTest()
        {
            var person = new
            {
                Name = "Smidth",
                Age = 30
            };
            AnonTypeArg(person);
        }

        static void Main(string[] args)
        {
            //AnonTypeTest();
            AnonTypeArgTest();
        }
    }
}
