﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace WebAppEntityFrameworkDbFirst.Models
{
    [Index(nameof(FacultyId), Name = "IX_Students_FacultyId")]
    public partial class Student
    {
        public Student()
        {
            CourseStudents = new HashSet<CourseStudent>();
        }

        [Key]
        public int StudentId { get; set; }
        [Required]
        [StringLength(40)]
        public string LastName { get; set; }
        public int FacultyId { get; set; }

        [ForeignKey(nameof(FacultyId))]
        [InverseProperty("Students")]
        public virtual Faculty Faculty { get; set; }
        [InverseProperty(nameof(CourseStudent.Student))]
        public virtual ICollection<CourseStudent> CourseStudents { get; set; }
    }
}
