﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace WebAppEntityFrameworkDbFirst.Models
{
    [Table("CourseStudent")]
    [Index(nameof(StudentId), Name = "IX_CourseStudent_StudentId")]
    public partial class CourseStudent
    {
        [Key]
        public int CourseId { get; set; }
        [Key]
        public int StudentId { get; set; }

        [ForeignKey(nameof(CourseId))]
        [InverseProperty("CourseStudents")]
        public virtual Course Course { get; set; }
        [ForeignKey(nameof(StudentId))]
        [InverseProperty("CourseStudents")]
        public virtual Student Student { get; set; }
    }
}
