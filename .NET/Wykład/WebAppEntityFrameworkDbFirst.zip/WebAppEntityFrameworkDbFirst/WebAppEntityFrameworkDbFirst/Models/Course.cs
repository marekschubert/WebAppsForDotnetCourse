﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace WebAppEntityFrameworkDbFirst.Models
{
    public partial class Course
    {
        public Course()
        {
            CourseStudents = new HashSet<CourseStudent>();
        }

        [Key]
        public int CourseId { get; set; }
        [Required]
        [StringLength(40)]
        public string CourseName { get; set; }

        [InverseProperty(nameof(CourseStudent.Course))]
        public virtual ICollection<CourseStudent> CourseStudents { get; set; }
    }
}
