﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace WebAppEntityFrameworkDbFirst.Models
{
    public partial class Faculty
    {
        public Faculty()
        {
            Students = new HashSet<Student>();
        }

        [Key]
        public int FacultyId { get; set; }
        [Required]
        [StringLength(40)]
        public string FacultyName { get; set; }

        [InverseProperty(nameof(Student.Faculty))]
        public virtual ICollection<Student> Students { get; set; }
    }
}
