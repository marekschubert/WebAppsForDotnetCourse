﻿using System.Collections;

namespace dotNET_lab10.Models
{
    public class CartArticleViewModel
    {
        public Article Article { get; set; }

        public int Quantity { get; set; }

    }
}
