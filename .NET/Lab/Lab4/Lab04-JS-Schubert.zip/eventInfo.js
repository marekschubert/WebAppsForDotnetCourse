function eventInfo(e){
    return  "key="+e.key+
            ", code="+e.code+" <hr> "+
            "clientX="+e.clientX+
            ", clientY="+e.clientY+" <hr> "+
            "screenX="+e.screenX+
            ", screenY="+e.screenY+" <hr> "+
            "ctrlKey="+e.ctrlKey+
            ", shiftKey="+e.shiftKey+
            ", altKey="+e.altKey+
            ", type="+e.type;
}
